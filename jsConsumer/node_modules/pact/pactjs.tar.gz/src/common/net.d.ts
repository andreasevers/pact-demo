export function isPortAvailable(port: number, host: string): Promise<void>;
